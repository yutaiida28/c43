$fichier = "TrueNAS-SCALE-24.10.2.iso"
$val_sha = "33e29ed62517bc5d4aed6c80b9134369e201bb143e13fefdec5dbf3820f4b946"
$algo    = "sha256"

$rep_SHA = (Get-FileHash -Path $fichier -Algorithm $algo).Hash

if ($rep_SHA -eq $val_sha)
{
  Write-Host "Le fichier '$fichier' est valide." -ForegroundColor Yellow
}
else
{
  Write-Host "Le fichier '$fichier' est invalide." -ForegroundColor Red
}
