#-----------------------------------
# Fait par Richard Jean
# Le 11 mars 2024
#
# Modification du DNS du SERVEUR2
#
# Script pour créer la structure du laboratoire
# "C43 L09A DNS - 1 de 2.docx"
#-----------------------------------
Clear-Host

#------------------------------------
# Création d'une zone principale
#------------------------------------
Add-DnsServerPrimaryZone -Name formation.local `
                         -ZoneFile formation.local.dns `
                         -DynamicUpdate None

#---------------------------------------------------------------
# Création des enregistrements "A" dans la zone "formation.local"
#---------------------------------------------------------------
Add-DnsServerResourceRecordA -Name serveur1 `
                             -IPv4Address 192.168.1.10 `
                             -ZoneName formation.local

Add-DnsServerResourceRecordA -Name serveur2 `
                             -IPv4Address 192.168.1.20 `
                             -ZoneName formation.local

Add-DnsServerResourceRecordA -Name adr1 `
                             -IPv4Address 192.168.1.101 `
                             -ZoneName formation.local

Add-DnsServerResourceRecordA -Name adr2 `
                             -IPv4Address 192.168.1.102 `
                             -ZoneName formation.local

Add-DnsServerResourceRecordA -Name adr3 `
                             -IPv4Address 192.168.1.103 `
                             -ZoneName formation.local

Add-DnsServerResourceRecordA -Name port `
                             -IPv4Address 192.168.1.10 `
                             -ZoneName formation.local

Add-DnsServerResourceRecordA -Name www `
                             -IPv4Address 192.168.1.10 `
                             -ZoneName formation.local
